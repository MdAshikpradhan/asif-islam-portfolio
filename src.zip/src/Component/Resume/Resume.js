import React from 'react';
import Navbar from '../../Shared/Navbar/Navbar';

const Resume = () => {
    return (
        <div>
            <Navbar />
            <h2>Resume</h2>
        </div>
    );
};

export default Resume;