import React from 'react';
import Linkedin from '../../images/linkedin.png';
import Linkedin2 from '../../images/linkedin2.png';
import './Portfolio.css';


const Portfolio = () => {
    return (
        <div className="container mt-5 pt-5 mb-5 pb-5">
            
            <div className="text-center mb-5">
                <h1>Project</h1>
            </div>
            <div className="container">
                <div className="row">
                    <div className="col-md-6 mb-3 cardContainer cardBg">
                        <div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <div className=" mb-5">
                                    <img src={Linkedin} className="d-block w-100 projectImg" alt="..." />
                                </div>
                            </div>
                            <div class="carousel-item  ">
                            <div className=" mb-5">
                                <img src={Linkedin2} className="d-block w-100 projectImg" alt="..." />
                            </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                        </div>
                        <div className="projectLink text-light">
                            <p className="text-center">
                                <a href="https://linkedin-clone-975b9.web.app/" > <i className="far fa-eye"></i> Preview </a>
                                 || <a href="https://github.com/MdAshikpradhan/linkedin-clone">Github code </a>
                            </p>
                            <h5>
                            Conditional login page. f the user logged in, it will show on the homepage. If the user has not logged in, then ask him to log in.
                            Logout can do as desired. Clicking on the profile icon in the header right will log out. After logging in, the user will see his name and email at the top left. Users can post their status, and it will show. In the feed news, the users can able see their name and email just like LinkedIn.
                            </h5>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Portfolio;